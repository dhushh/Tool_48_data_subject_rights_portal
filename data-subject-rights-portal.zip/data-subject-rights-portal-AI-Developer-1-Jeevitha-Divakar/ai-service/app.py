import os
import json
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
from dotenv import load_dotenv
import time
import hashlib
import redis
from sentence_transformers import SentenceTransformer
import re
from markupsafe import escape
import chromadb

chroma_client = chromadb.PersistentClient(path="./chroma_db")
collection = chroma_client.get_collection(name="dsr_knowledge")

# Pre-loading the model at startup for faster response times
print("Pre-loading sentence-transformers model...")
embedding_model = SentenceTransformer('all-MiniLM-L6-v2') 
print("Model loaded successfully.")


try:
    collection = chroma_client.get_collection(name="dsr_knowledge")
    print("ChromaDB Collection 'dsr_knowledge' loaded successfully.")
except Exception as e:
    print(f"Warning: Could not find collection. Ensure you ran seed_db.py. Error: {e}")
    collection = None


load_dotenv()

cache = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)

START_TIME = time.time()
response_times = []

app = Flask(__name__)
CORS(app) # Necessary for the Java/React layers to talk to Flask

GROQ_API_KEY = os.getenv("GROQ_API_KEY")
MODEL = "llama-3.3-70b-versatile"

def sanitize_input(text):
    # Escape HTML characters to prevent XSS
    text = escape(text)
    return text

def get_ai_description(user_input, context=""):
    # 1. Loading Prompt Template
    with open("prompts/describe_rights.txt", "r") as f:
        template = f.read()
    

    full_prompt = template.replace("{user_input}", user_input).replace("{context}", context)

    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    
    data = {
        "model": MODEL,
        "messages": [
            {
                "role": "system", 
                "content": "You are a Data Privacy Expert. Use the provided domain context to categorize requests according to company policy."
            },
            {"role": "user", "content": full_prompt}
        ],
        "temperature": 0.2, # Lowered to 0.2 for Day 9 performance/consistency
        "response_format": {"type": "json_object"} 
    }

    response = requests.post("https://api.groq.com/openai/v1/chat/completions", headers=headers, json=data)
    response.raise_for_status()
    
    # Extracting the JSON string from AI response
    content = response.json()['choices'][0]['message']['content']
    return json.loads(content)

def get_ai_recommendations(user_input):
    with open("prompts/recommendations.txt", "r") as f:
        template = f.read()
    
    full_prompt = template.replace("{user_input}", user_input)

    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    
    data = {
        "model": MODEL,
        "messages": [{"role": "user", "content": full_prompt}],
        "temperature": 0.5, # Slightly higher for creative suggestions
        "response_format": {"type": "json_object"}
    }

    response = requests.post("https://api.groq.com/openai/v1/chat/completions", headers=headers, json=data)
    response.raise_for_status()
    
    # Extract the array from the JSON response
    content = json.loads(response.json()['choices'][0]['message']['content'])
    
    # Ensure it returns the list part if the AI wraps it in a key like "recommendations"
    if isinstance(content, dict):
        for key in content:
            if isinstance(content[key], list):
                return content[key]
    return content

def get_ai_report(user_input):
    with open("prompts/report_template.txt", "r") as f:
        template = f.read()
    
    full_prompt = template.replace("{user_input}", user_input)

    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    
    data = {
        "model": MODEL,
        "messages": [{"role": "user", "content": full_prompt}],
        "temperature": 0.4, # Balanced for structure and detail
        "response_format": {"type": "json_object"}
    }

    response = requests.post("https://api.groq.com/openai/v1/chat/completions", headers=headers, json=data)
    response.raise_for_status()
    return json.loads(response.json()['choices'][0]['message']['content'])

@app.route('/describe', methods=['POST'])
def describe_request():
    start = time.time()
    data = request.get_json()
    
    # APPLY SANITIZATION HERE
    text_input = sanitize_input(data.get('text', ''))
    
    if not text_input:
        return jsonify({"error": "Missing 'text' field"}), 400    
    
    if not request.is_json:
        return jsonify({"error": "Content-Type must be application/json"}), 415
        
    data = request.get_json()

    # 1. Validate Input
    if not data or 'text' not in data:
        response_times.append(time.time() - start)
        return jsonify({"error": "Missing 'text' field"}), 400

    text_input = data['text']
    
    if len(text_input) > 5000:
        return jsonify({"error": "Request body too large"}), 413
    
    # 2. Cache Check (SHA256 Hash)
    cache_key = f"describe:{hashlib.sha256(text_input.encode()).hexdigest()}"
    
    try:
        cached_result = cache.get(cache_key)
        if cached_result:
            ai_response = json.loads(cached_result)
        else:
            # 3. Retrieve Domain Knowledge from ChromaDB
            context = ""
            if collection:
                try:
                    results = collection.query(
                        query_texts=[text_input],
                        n_results=2 
                    )
                    if results['documents']:
                        context = " ".join(results['documents'][0])
                except Exception as db_e:
                    app.logger.error(f"ChromaDB Query Error: {str(db_e)}")
            
            # 4. Call AI Logic (Now context is safely handled even if empty)
            ai_response = get_ai_description(text_input, context)

            ai_response['generated_at'] = datetime.utcnow().isoformat() + "Z"
            
            # 5. Store in Redis (15-minute TTL)
            cache.setex(cache_key, 900, json.dumps(ai_response))
            
        response_times.append(time.time() - start)
        return jsonify(ai_response), 200
        
    except Exception as e:
        response_times.append(time.time() - start)
        app.logger.error(f"Internal Error: {str(e)}")
        return jsonify({
            "action_type": "Manual Review Required",
            "description": "The AI service is currently unavailable. Please verify this request manually.",
            "priority": "High",
            "is_fallback": True,
            "generated_at": datetime.utcnow().isoformat() + "Z"
        }), 200
    
@app.route('/recommend', methods=['POST'])
def recommend_actions():
    start = time.time()
    data = request.get_json()
    
    # APPLY SANITIZATION HERE
    text_input = sanitize_input(data.get('text', ''))
    
    if not text_input:
        return jsonify({"error": "Missing 'text' field"}), 400
    
    if not request.is_json:
        return jsonify({"error": "Content-Type must be application/json"}), 415
    
    if len(data['text']) > 5000:
        return jsonify({"error": "Request body too large"}), 413
    
    if not data or 'text' not in data:
        response_times.append(time.time() - start)
        return jsonify({"error": "Missing 'text' field"}), 400
    
    text_input = data['text']
    # Create a specific key for recommendations to avoid collisions with /describe
    cache_key = f"recommend:{hashlib.sha256(text_input.encode()).hexdigest()}"

    try:
        # Check Redis
        cached_result = cache.get(cache_key)
        if cached_result:
            recommendations = json.loads(cached_result)
        else:
            # Call AI and cache the result for 15 minutes
            recommendations = get_ai_recommendations(text_input)
            cache.setex(cache_key, 900, json.dumps(recommendations))
        
        response_times.append(time.time() - start)
        return jsonify(recommendations[:3]), 200
        
    except Exception as e:
        response_times.append(time.time() - start)
        # Log the real error internally for your own debugging
        app.logger.error(f"Internal Error: {str(e)}")
        # Standard fallback if AI fails - Wrapped in {} inside the []
        return jsonify([
            {
                "action_type": "Manual Review Required", 
                "description": "The AI service is currently unavailable. Please verify this request manually.", 
                "priority": "High",
                "is_fallback": True,
                "generated_at": datetime.utcnow().isoformat() + "Z"
            },
            {"action_type": "Identity Verification", "description": "Verify the identity of the requester manually.", "priority": "High"},
            {"action_type": "Legal Review", "description": "Consult the legal team regarding this request.", "priority": "Medium"},
            {"action_type": "Internal Log", "description": "Document this request in the manual audit log.", "priority": "Low"}
        ]), 200

@app.route('/generate-report', methods=['POST'])
def generate_report():
    start = time.time()
    data = request.get_json()
    
    # APPLY SANITIZATION HERE
    text_input = sanitize_input(data.get('text', ''))
    
    if not text_input:
        return jsonify({"error": "Missing 'text' field"}), 400

    if not request.is_json:
        return jsonify({"error": "Content-Type must be application/json"}), 415
    
    if len(data['text']) > 5000:
        return jsonify({"error": "Request body too large"}), 413

    if not data or 'text' not in data:
        response_times.append(time.time() - start)
        return jsonify({"error": "Missing 'text' field"}), 400
    
    text_input = data['text']
    cache_key = f"report:{hashlib.sha256(text_input.encode()).hexdigest()}"

    try:
        cached_result = cache.get(cache_key)
        if cached_result:
            report = json.loads(cached_result)
        else:
            report = get_ai_report(text_input)
            cache.setex(cache_key, 900, json.dumps(report))
            
        response_times.append(time.time() - start)
        return jsonify(report), 200
    
    except Exception as e:
        response_times.append(time.time() - start)
        # Log the real error internally for your own debugging
        app.logger.error(f"Internal Error: {str(e)}")
        return jsonify({
            "action_type": "Manual Review Required",
            "description": "The AI service is currently unavailable. Please verify this request manually.",
            "priority": "High",
            "is_fallback": True, # Required for Day 9
            "generated_at": datetime.utcnow().isoformat() + "Z"
        }), 200
    
@app.route('/health', methods=['GET'])
def health():
    avg_time = sum(response_times) / len(response_times) if response_times else 0
    uptime = time.time() - START_TIME
    
    return jsonify({
        "status": "up",
        "model": MODEL,
        "avg_response_time_sec": round(avg_time, 3),
        "uptime_sec": int(uptime),
        "request_count": len(response_times),
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }), 200

@app.after_request
def add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    return response

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)